import random
r = random.randint(0, 999)
print("ネコ"*r + "タコ" + "ネコ"*(1000-r))
